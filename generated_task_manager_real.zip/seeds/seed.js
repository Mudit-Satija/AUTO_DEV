const mongoose = require('mongoose');
const connectDB = require('../backend/src/config/database');
const Users = require('../backend/src/models/users');
const Tasks = require('../backend/src/models/tasks');
const Categories = require('../backend/src/models/categories');

(async () => {
  await connectDB();

  const categories = await Categories.create([
    { name: 'Work' },
    { name: 'Personal' },
    { name: 'Health' },
    { name: 'Learning' }
  ]);

  const users = await Users.create([
    {
      username: 'john_doe',
      email: 'john@example.com',
      password: '$2a$10$examplehashedpassword123456789012345678901234567890123456789012345' // bcrypt hash
    },
    {
      username: 'jane_smith',
      email: 'jane@example.com',
      password: '$2a$10$examplehashedpassword098765432109876543210987654321098765432109876' // bcrypt hash
    }
  ]);

  await Tasks.create([
    {
      title: 'Complete project proposal',
      description: 'Draft and submit the Q3 project proposal',
      completed: false,
      priority: 'high',
      categoryId: categories[0]._id,
      userId: users[0]._id
    },
    {
      title: 'Morning workout',
      description: '30 minutes cardio and strength training',
      completed: true,
      priority: 'medium',
      categoryId: categories[2]._id,
      userId: users[0]._id
    },
    {
      title: 'Read new book chapter',
      description: 'Finish chapter 5 of "Clean Code"',
      completed: false,
      priority: 'low',
      categoryId: categories[3]._id,
      userId: users[1]._id
    },
    {
      title: 'Schedule dentist appointment',
      description: 'Book checkup for next week',
      completed: false,
      priority: 'medium',
      categoryId: categories[2]._id,
      userId: users[1]._id
    }
  ]);

  console.log('Seed data inserted successfully.');

  await mongoose.connection.close();
})();