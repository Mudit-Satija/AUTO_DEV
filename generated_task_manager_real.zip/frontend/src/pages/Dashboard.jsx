import React, { useState, useEffect } from 'react'
import api from '../services/api'

const Dashboard = () => {
  const [stats, setStats] = useState({ tasks: 0, categories: 0, users: 0 })
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const [tasksRes, categoriesRes, usersRes] = await Promise.all([
          api.get('/tasks/count'),
          api.get('/categories/count'),
          api.get('/users/count')
        ])
        setStats({
          tasks: tasksRes.data.count,
          categories: categoriesRes.data.count,
          users: usersRes.data.count
        })
      } catch (err) {
        setError(err.response?.data?.message || 'Failed to fetch dashboard stats')
      } finally {
        setLoading(false)
      }
    }

    fetchStats()
  }, [])

  if (loading) return <div>Loading dashboard...</div>
  if (error) return <div>Error: {error}</div>

  return (
    <div>
      <h1>Dashboard</h1>
      <div>
        <p><strong>Tasks:</strong> {stats.tasks}</p>
        <p><strong>Categories:</strong> {stats.categories}</p>
        <p><strong>Users:</strong> {stats.users}</p>
      </div>
    </div>
  )
}

export default Dashboard