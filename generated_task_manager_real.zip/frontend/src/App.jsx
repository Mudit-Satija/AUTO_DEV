import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Dashboard from './pages/Dashboard.jsx';
import Tasks from './pages/Tasks.jsx';
import Categories from './pages/Categories.jsx';
import Login from './pages/Login.jsx';
import Register from './pages/Register.jsx';
import './App.css';

function App() {
  return (
    <Router>
      <div className="app">
        <header className="header">
          <div className="navbar">
            <h1>Task Manager</h1>
            <div>
              <a href="/dashboard">Dashboard</a>
              <a href="/tasks">Tasks</a>
              <a href="/categories">Categories</a>
            </div>
          </div>
        </header>
        <main className="main">
          <Routes>
            <Route path="/" element={<Login />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/tasks" element={<Tasks />} />
            <Route path="/categories" element={<Categories />} />
          </Routes>
        </main>
        <footer className="footer">
          <p>&copy; 2023 Task Manager. All rights reserved.</p>
        </footer>
      </div>
    </Router>
  );
}

export default App;