# Task Management System

A full-stack task management application built with Express.js, React, and MongoDB, featuring JWT-based authentication.

## Features

- User registration and login with JWT authentication
- Manage tasks with categories
- Protected routes for authenticated users only
- Clean separation of concerns with modular backend structure
- Responsive React frontend with dedicated pages for each feature

## Backend Structure

- `src/server/` - Express.js server
  - `app.js` - Main Express application
  - `routes/` - API route handlers
    - `auth.js` - Authentication routes (login, register)
    - `tasks.js` - Task management routes
    - `categories.js` - Category management routes
    - `users.js` - User management routes
  - `models/` - Mongoose schemas
    - `Task.js`
    - `Category.js`
    - `User.js`
  - `middleware/` - Authentication middleware
    - `auth.js` - JWT verification middleware

## Frontend Structure

- `src/` - React application
  - `pages/` - Page components
    - `Dashboard.jsx` - Main dashboard view
    - `Tasks.jsx` - Task management interface
    - `Categories.jsx` - Category management interface
    - `Login.jsx` - User login form
    - `Register.jsx` - User registration form
  - `components/` - Reusable UI components
  - `services/` - API service calls
  - `context/` - Auth context for state management

## Prerequisites

- Node.js (v18+)
- MongoDB (local or cloud instance)
- npm or yarn

## Setup Instructions

### Backend Setup

1. Clone the repository:
   ```
   git clone <repository-url>
   cd <project-directory>
   ```

2. Install backend dependencies:
   ```
   cd src/server
   npm install
   ```

3. Create a `.env` file in `src/server/`:
   ```
   PORT=5000
   MONGO_URI=mongodb://localhost:27017/taskmanager
   JWT_SECRET=your-jwt-secret-key-here
   ```

4. Start the backend server:
   ```
   npm start
   ```

### Frontend Setup

1. Install frontend dependencies:
   ```
   cd ../..
   cd src/client
   npm install
   ```

2. Create a `.env` file in `src/client/`:
   ```
   VITE_API_BASE_URL=http://localhost:5000/api
   ```

3. Start the frontend development server:
   ```
   npm run dev
   ```

## Usage

1. Navigate to http://localhost:5173 (default Vite port)
2. Register a new account or login with existing credentials
3. Once authenticated, access the Dashboard, Tasks, and Categories pages
4. Create, update, and delete tasks and categories as needed

## Environment Variables

### Backend (.env)
- `PORT` - Server port (default: 5000)
- `MONGO_URI` - MongoDB connection string
- `JWT_SECRET` - Secret key for JWT signing

### Frontend (.env)
- `VITE_API_BASE_URL` - Base URL for API calls (must match backend port)

## API Endpoints

### Auth (Public)
- POST /api/auth/login
- POST /api/auth/register

### Protected (Requires JWT token in Authorization header)
- GET /api/tasks
- POST /api/tasks
- PUT /api/tasks/:id
- DELETE /api/tasks/:id
- GET /api/categories
- POST /api/categories
- PUT /api/categories/:id
- DELETE /api/categories/:id
- GET /api/users/me

## License

MIT