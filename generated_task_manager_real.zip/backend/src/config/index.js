require('dotenv').config();

module.exports = () => {
  // Configuration loader - ensures environment variables are loaded
};