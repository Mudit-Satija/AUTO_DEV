const mongoose = require('mongoose');
const connectDB = require('../backend/src/config/database');
const Calculator = require('../backend/src/models/calculator');

async function seed() {
  await connectDB();

  const calculatorData = [
    { expression: '2 + 2', result: 4, createdAt: new Date() },
    { expression: '10 - 5', result: 5, createdAt: new Date() },
    { expression: '3 * 4', result: 12, createdAt: new Date() },
    { expression: '15 / 3', result: 5, createdAt: new Date() },
    { expression: '8 ^ 2', result: 64, createdAt: new Date() }
  ];

  await Calculator.deleteMany({});
  await Calculator.insertMany(calculatorData);

  console.log('Seed data inserted successfully.');

  mongoose.connection.close();
}

seed().catch(err => {
  console.error('Error seeding data:', err);
  mongoose.connection.close();
});