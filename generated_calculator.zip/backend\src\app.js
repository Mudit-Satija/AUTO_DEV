const express = require('express');
const config = require('./config/index');
const connectDB = require('./config/database');
const errorHandler = require('./middleware/errorHandler');
const router = require('./routes/index');

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use('/api', router);

app.use(errorHandler);

connectDB().then(() => {
  app.listen(config.PORT, () => {
    console.log(`Server running on port ${config.PORT}`);
  });
});