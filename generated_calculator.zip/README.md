# Calculator Project

A simple calculator application built with Express.js for the backend and React for the frontend, using MongoDB as the database. Authentication is disabled.

## Project Structure

- Backend: Express.js with MongoDB/Mongoose
- Frontend: React with Vite
- Database: MongoDB
- Auth: Disabled
- Required Modules: calculator (backend), Calculator (frontend)

## Prerequisites

- Node.js (v18 or higher)
- MongoDB (running locally or via MongoDB Atlas)
- npm or yarn

## Setup Instructions

### 1. Clone the Repository

```bash
git clone <repository-url>
cd calculator-project
```

### 2. Install Backend Dependencies

```bash
cd backend
npm install
```

### 3. Install Frontend Dependencies

```bash
cd ../frontend
npm install
```

### 4. Configure MongoDB Connection

Ensure MongoDB is running. The backend connects to `mongodb://localhost:27017/calculator-db` by default. If you're using a different URI, update the connection string in `backend/config/db.js`.

### 5. Start the Backend Server

```bash
cd backend
npm start
```

The backend will run on `http://localhost:5000`.

### 6. Start the Frontend Development Server

```bash
cd ../frontend
npm run dev
```

The frontend will run on `http://localhost:5173`.

## Usage

1. Open `http://localhost:5173` in your browser.
2. Use the Calculator interface to perform basic arithmetic operations.
3. All calculations are stored in MongoDB (no authentication required).

## API Endpoints

- `GET /api/calculator` — Returns calculator functionality (handled internally by Express router)
- `POST /api/calculator/calculate` — Performs calculation (body: { expression: "2+2" })

## Notes

- No authentication is implemented or required.
- All data is stored in MongoDB using Mongoose.
- The frontend only imports the Calculator page as specified.
- The backend only uses the calculator module as specified.

## Folder Structure

```
calculator-project/
├── backend/
│   ├── app.js
│   ├── config/
│   │   └── db.js
│   ├── routes/
│   │   └── calculator.js
│   ├── modules/
│   │   └── calculator.js
│   └── package.json
└── frontend/
    ├── src/
    │   ├── pages/
    │   │   └── Calculator.jsx
    │   └── main.jsx
    └── package.json
```

## License

MIT