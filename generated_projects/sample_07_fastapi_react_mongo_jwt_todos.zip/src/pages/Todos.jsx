import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { getTodos, createTodo, deleteTodo, updateTodo } from '../services/api';

const Todos = () => {
  const [todos, setTodos] = useState([]);
  const [newTodo, setNewTodo] = useState('');
  const [editingId, setEditingId] = useState(null);
  const [editText, setEditText] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) {
      navigate('/');
      return;
    }

    fetchTodos();
  }, []);

  const fetchTodos = async () => {
    setLoading(true);
    try {
      const data = await getTodos();
      setTodos(data);
      setError('');
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to fetch todos');
    } finally {
      setLoading(false);
    }
  };

  const handleAddTodo = async (e) => {
    e.preventDefault();
    if (!newTodo.trim()) return;

    try {
      const todo = await createTodo(newTodo);
      setTodos([...todos, todo]);
      setNewTodo('');
      setSuccess('Todo added successfully!');
      setTimeout(() => setSuccess(''), 3000);
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to add todo');
    }
  };

  const handleDeleteTodo = async (id) => {
    try {
      await deleteTodo(id);
      setTodos(todos.filter(todo => todo._id !== id));
      setSuccess('Todo deleted successfully!');
      setTimeout(() => setSuccess(''), 3000);
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to delete todo');
    }
  };

  const handleEditClick = (todo) => {
    setEditingId(todo._id);
    setEditText(todo.text);
  };

  const handleUpdateTodo = async (e) => {
    e.preventDefault();
    if (!editText.trim()) return;

    try {
      const updatedTodo = await updateTodo(editingId, editText);
      setTodos(todos.map(todo =>
        todo._id === editingId ? updatedTodo : todo
      ));
      setEditingId(null);
      setEditText('');
      setSuccess('Todo updated successfully!');
      setTimeout(() => setSuccess(''), 3000);
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to update todo');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    navigate('/');
  };

  return (
    <div className="todos-container">
      <div className="todos-header">
        <h2>My Todos</h2>
        <button className="logout-btn" onClick={handleLogout}>Logout</button>
      </div>

      {error && <div className="error-message">{error}</div>}
      {success && <div className="success-message">{success}</div>}

      <form onSubmit={handleAddTodo} className="add-todo-form">
        <input
          type="text"
          placeholder="Add a new todo..."
          value={newTodo}
          onChange={(e) => setNewTodo(e.target.value)}
          required
        />
        <button type="submit">Add</button>
      </form>

      {loading ? (
        <div className="loading">Loading todos...</div>
      ) : (
        <div>
          {todos.length === 0 ? (
            <p style={{ textAlign: 'center', color: '#666' }}>No todos yet. Add one above!</p>
          ) : (
            todos.map(todo => (
              <div key={todo._id} className="todo-item">
                {editingId === todo._id ? (
                  <form onSubmit={handleUpdateTodo} style={{ flex: 1 }}>
                    <input
                      type="text"
                      value={editText}
                      onChange={(e) => setEditText(e.target.value)}
                      autoFocus
                      style={{ flex: 1, marginRight: '10px', padding: '8px', border: '1px solid #ddd', borderRadius: '4px' }}
                    />
                    <button type="submit" style={{ padding: '8px 12px', backgroundColor: '#28a745', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>
                      Save
                    </button>
                  </form>
                ) : (
                  <>
                    <span className="todo-text">{todo.text}</span>
                    <div className="todo-actions">
                      <button className="edit-btn" onClick={() => handleEditClick(todo)}>Edit</button>
                      <button className="delete-btn" onClick={() => handleDeleteTodo(todo._id)}>Delete</button>
                    </div>
                  </>
                )}
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
};

export default Todos;