from fastapi import APIRouter, Depends, HTTPException, status
from typing import List
from app.schemas.todos import TodoCreate, TodoOut
from app.services.todos import create_todo, get_todos, get_todo_by_id, update_todo, delete_todo
from app.database import get_database
from app.auth import get_current_user
from bson import ObjectId

router = APIRouter()

@router.post("/", response_model=TodoOut, status_code=status.HTTP_201_CREATED)
async def create_new_todo(todo: TodoCreate, current_user: dict = Depends(get_current_user), db=Depends(get_database)):
    todo_data = todo.dict()
    todo_data["user_id"] = current_user["_id"]
    created_todo = await create_todo(db, todo_data)
    return created_todo

@router.get("/", response_model=List[TodoOut])
async def read_todos(current_user: dict = Depends(get_current_user), db=Depends(get_database)):
    todos = await get_todos(db, current_user["_id"])
    return todos

@router.get("/{todo_id}", response_model=TodoOut)
async def read_todo(todo_id: str, current_user: dict = Depends(get_current_user), db=Depends(get_database)):
    todo = await get_todo_by_id(db, todo_id)
    if not todo or todo["user_id"] != current_user["_id"]:
        raise HTTPException(status_code=404, detail="Todo not found")
    return todo

@router.put("/{todo_id}", response_model=TodoOut)
async def update_existing_todo(todo_id: str, todo: TodoCreate, current_user: dict = Depends(get_current_user), db=Depends(get_database)):
    updated_todo = await update_todo(db, todo_id, todo.dict(), current_user["_id"])
    if not updated_todo:
        raise HTTPException(status_code=404, detail="Todo not found or not authorized")
    return updated_todo

@router.delete("/{todo_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_existing_todo(todo_id: str, current_user: dict = Depends(get_current_user), db=Depends(get_database)):
    deleted = await delete_todo(db, todo_id, current_user["_id"])
    if not deleted:
        raise HTTPException(status_code=404, detail="Todo not found or not authorized")
    return None