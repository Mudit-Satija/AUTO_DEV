from fastapi import APIRouter, Depends, HTTPException, status
from typing import List
from app.schemas.notes import NoteCreate, NoteOut
from app.services.notes import create_note, get_notes, get_note_by_id, update_note, delete_note
from app.database import get_database
from app.auth import get_current_user
from bson import ObjectId

router = APIRouter()

@router.post("/", response_model=NoteOut, status_code=status.HTTP_201_CREATED)
async def create_new_note(note: NoteCreate, current_user: dict = Depends(get_current_user), db=Depends(get_database)):
    note_data = note.dict()
    note_data["user_id"] = current_user["_id"]
    created_note = await create_note(db, note_data)
    return created_note

@router.get("/", response_model=List[NoteOut])
async def read_notes(current_user: dict = Depends(get_current_user), db=Depends(get_database)):
    notes = await get_notes(db, current_user["_id"])
    return notes

@router.get("/{note_id}", response_model=NoteOut)
async def read_note(note_id: str, current_user: dict = Depends(get_current_user), db=Depends(get_database)):
    note = await get_note_by_id(db, note_id)
    if not note or note["user_id"] != current_user["_id"]:
        raise HTTPException(status_code=404, detail="Note not found")
    return note

@router.put("/{note_id}", response_model=NoteOut)
async def update_existing_note(note_id: str, note: NoteCreate, current_user: dict = Depends(get_current_user), db=Depends(get_database)):
    updated_note = await update_note(db, note_id, note.dict(), current_user["_id"])
    if not updated_note:
        raise HTTPException(status_code=404, detail="Note not found or not authorized")
    return updated_note

@router.delete("/{note_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_existing_note(note_id: str, current_user: dict = Depends(get_current_user), db=Depends(get_database)):
    deleted = await delete_note(db, note_id, current_user["_id"])
    if not deleted:
        raise HTTPException(status_code=404, detail="Note not found or not authorized")
    return None