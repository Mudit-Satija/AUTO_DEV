from app.database import get_database
from bson import ObjectId
from datetime import datetime
from typing import List, Dict, Any

async def create_todo(db, todo_data: Dict[str, Any]) -> Dict[str, Any]:
    todo_data["created_at"] = datetime.utcnow()
    todo_data["updated_at"] = datetime.utcnow()
    result = await db.todos.insert_one(todo_data)
    todo_data["_id"] = str(result.inserted_id)
    return todo_data

async def get_todos(db, user_id: str) -> List[Dict[str, Any]]:
    cursor = db.todos.find({"user_id": user_id})
    todos = []
    async for todo in cursor:
        todo["_id"] = str(todo["_id"])
        todos.append(todo)
    return todos

async def get_todo_by_id(db, todo_id: str) -> Dict[str, Any]:
    if not ObjectId.is_valid(todo_id):
        return None
    todo = await db.todos.find_one({"_id": ObjectId(todo_id)})
    if todo:
        todo["_id"] = str(todo["_id"])
    return todo

async def update_todo(db, todo_id: str, todo_data: Dict[str, Any], user_id: str) -> Dict[str, Any]:
    if not ObjectId.is_valid(todo_id):
        return None
    todo = await db.todos.find_one({"_id": ObjectId(todo_id), "user_id": user_id})
    if not todo:
        return None
    todo_data["updated_at"] = datetime.utcnow()
    await db.todos.update_one({"_id": ObjectId(todo_id)}, {"$set": todo_data})
    todo_data["_id"] = todo_id
    return todo_data

async def delete_todo(db, todo_id: str, user_id: str) -> bool:
    if not ObjectId.is_valid(todo_id):
        return False
    result = await db.todos.delete_one({"_id": ObjectId(todo_id), "user_id": user_id})
    return result.deleted_count > 0