from app.database import get_database
from bson import ObjectId
from datetime import datetime
from typing import List, Dict, Any

async def create_note(db, note_data: Dict[str, Any]) -> Dict[str, Any]:
    note_data["created_at"] = datetime.utcnow()
    note_data["updated_at"] = datetime.utcnow()
    result = await db.notes.insert_one(note_data)
    note_data["_id"] = str(result.inserted_id)
    return note_data

async def get_notes(db, user_id: str) -> List[Dict[str, Any]]:
    cursor = db.notes.find({"user_id": user_id})
    notes = []
    async for note in cursor:
        note["_id"] = str(note["_id"])
        notes.append(note)
    return notes

async def get_note_by_id(db, note_id: str) -> Dict[str, Any]:
    if not ObjectId.is_valid(note_id):
        return None
    note = await db.notes.find_one({"_id": ObjectId(note_id)})
    if note:
        note["_id"] = str(note["_id"])
    return note

async def update_note(db, note_id: str, note_data: Dict[str, Any], user_id: str) -> Dict[str, Any]:
    if not ObjectId.is_valid(note_id):
        return None
    note = await db.notes.find_one({"_id": ObjectId(note_id), "user_id": user_id})
    if not note:
        return None
    note_data["updated_at"] = datetime.utcnow()
    await db.notes.update_one({"_id": ObjectId(note_id)}, {"$set": note_data})
    note_data["_id"] = note_id
    return note_data

async def delete_note(db, note_id: str, user_id: str) -> bool:
    if not ObjectId.is_valid(note_id):
        return False
    result = await db.notes.delete_one({"_id": ObjectId(note_id), "user_id": user_id})
    return result.deleted_count > 0