# FastAPI + React + MongoDB JWT Auth Project

A full-stack web application using FastAPI as the backend, React as the frontend, MongoDB as the database, and JWT for authentication.

## Features

- Secure user authentication with JWT tokens
- Protected routes on both frontend and backend
- MongoDB for data persistence
- CORS configured for React frontend
- Environment variable support
- Clean, modular code structure

## Prerequisites

- Python 3.8+
- Node.js 16+
- MongoDB (local or cloud)
- pip (Python package manager)
- npm or yarn

## Setup Instructions

### 1. Clone the Repository

```bash
git clone https://github.com/yourusername/fastapi-react-mongodb-jwt.git
cd fastapi-react-mongodb-jwt
```

### 2. Set Up Backend (FastAPI)

Navigate to the backend directory:

```bash
cd backend
```

Create a virtual environment (optional but recommended):

```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

Install dependencies:

```bash
pip install -r requirements.txt
```

Create a `.env` file in the `backend` directory:

```env
SECRET_KEY=your-very-secret-key-here
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=30
MONGO_URI=mongodb://localhost:27017
MONGO_DB_NAME=auth_db
```

> Replace `your-very-secret-key-here` with a strong random string.

Start the FastAPI server:

```bash
uvicorn main:app --reload
```

The backend will be available at `http://127.0.0.1:8000`.

### 3. Set Up Frontend (React)

Navigate to the frontend directory:

```bash
cd ../frontend
```

Install dependencies:

```bash
npm install
```

Create a `.env` file in the `frontend` directory:

```env
REACT_APP_API_BASE_URL=http://localhost:8000
```

Start the React development server:

```bash
npm start
```

The frontend will be available at `http://localhost:3000`.

### 4. Start MongoDB

Ensure MongoDB is running locally or connect to a MongoDB Atlas cluster.

If using local MongoDB:

```bash
mongod
```

If using MongoDB Atlas, update the `MONGO_URI` in your `.env` file to point to your Atlas connection string.

### 5. Usage

- Visit `http://localhost:3000` to access the frontend.
- Register a new user or log in with existing credentials.
- JWT tokens are stored in localStorage and sent automatically with protected requests.
- The backend validates tokens on protected endpoints.

## Project Structure

```
fastapi-react-mongodb-jwt/
├── backend/
│   ├── main.py
│   ├── models/
│   │   └── user.py
│   ├── schemas/
│   │   └── user.py
│   ├── crud/
│   │   └── user.py
│   ├── auth/
│   │   ├── security.py
│   │   └── tokens.py
│   ├── database/
│   │   └── mongo.py
│   ├── .env
│   └── requirements.txt
└── frontend/
    ├── public/
    ├── src/
    │   ├── components/
    │   │   ├── Auth/
    │   │   │   ├── Login.jsx
    │   │   │   └── Register.jsx
    │   │   └── Protected/
    │   │       └── Dashboard.jsx
    │   ├── context/
    │   │   └── AuthContext.jsx
    │   ├── services/
    │   │   └── api.js
    │   ├── App.jsx
    │   └── main.jsx
    ├── .env
    ├── package.json
    └── README.md
```

## Environment Variables

### Backend (.env)

- `SECRET_KEY`: Secret key for JWT signing
- `ALGORITHM`: JWT algorithm (default: HS256)
- `ACCESS_TOKEN_EXPIRE_MINUTES`: Token expiration time in minutes
- `MONGO_URI`: MongoDB connection URI
- `MONGO_DB_NAME`: Database name to use

### Frontend (.env)

- `REACT_APP_API_BASE_URL`: Base URL of the FastAPI backend

## Security Notes

- Never commit `.env` files to version control.
- Use HTTPS in production.
- Consider adding rate limiting and input validation.
- Refresh tokens can be implemented for enhanced security.

## License

MIT