const mongoose = require('mongoose');
const bcrypt = require('bcrypt');

const connectDB = async () => {
  try {
    await mongoose.connect('mongodb://localhost:27017/yourdb', {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    console.log('MongoDB connected');
  } catch (err) {
    console.error(err.message);
    process.exit(1);
  }
};

const seedUsers = async () => {
  const User = mongoose.model('User', new mongoose.Schema({
    username: String,
    email: String,
    password: String,
    createdAt: { type: Date, default: Date.now }
  }));

  const hashedPassword = await bcrypt.hash('password123', 10);

  const users = [
    {
      username: 'admin',
      email: 'admin@example.com',
      password: hashedPassword
    },
    {
      username: 'user1',
      email: 'user1@example.com',
      password: hashedPassword
    }
  ];

  await User.insertMany(users);
  console.log('Seed data inserted');
};

connectDB().then(() => {
  seedUsers().then(() => {
    mongoose.connection.close();
  });
});